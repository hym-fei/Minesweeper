package minesweeper;

import processing.core.PApplet;
import processing.core.PImage;
import processing.event.MouseEvent;

import java.util.HashMap;
import java.util.Random;
import java.util.ArrayList;
import java.util.List;

public class App extends PApplet {

    public static final int CELLSIZE = 32;
    public static final int TOPBAR = 64;
    public static int WIDTH = 864;
    public static int HEIGHT = 640;
    public static final int BOARD_WIDTH = WIDTH / CELLSIZE;
    public static final int BOARD_HEIGHT = (HEIGHT - TOPBAR) / CELLSIZE;
    public static final int FPS = 30;
    public static final int DEFAULT_MINES = 100;

    private Tile[][] board;
    private HashMap<String, PImage> s1 = new HashMap<>();
    public boolean gameOver = false;
    private int numberMines;
    private int passedTime = 0;
    private boolean gameWon = false;
    private int explosionStartFrame = -1;
    private List<Tile> explodingMines = new ArrayList<>();

    public PImage getS1(String s) {
        PImage consequence = s1.get(s);
        if (consequence == null) {
            consequence = loadImage(this.getClass().getResource(s + ".png").getPath().toLowerCase().replace("%20", " "));
            s1.put(s, consequence);
        }
        return consequence;
    }

    public Tile[][] getBoard() {
        return this.board;
    }

    @Override
    public void settings() {
        size(WIDTH, HEIGHT);
    }

    @Override
    public void setup() {
        frameRate(FPS);
        resetGame();
    }

    public void resetGame() {
        gameWon = false;
        gameOver = false;
        passedTime = 0;
        explosionStartFrame = -1;
        explodingMines.clear();

        if (args != null && args.length > 0) {
            try {
                numberMines = Integer.parseInt(args[0]);
            } catch (NumberFormatException e) {
                numberMines = DEFAULT_MINES;
            }
        } else {
            numberMines = DEFAULT_MINES;
        }

        String[] imagesToLoad = {"tile1", "tile2", "flag", "tile"};
        for (String s2 : imagesToLoad) {
            getS1(s2);
        }

        for (int i = 0; i < 10; i++) {
            getS1("mine" + i);
        }

        this.board = new Tile[BOARD_HEIGHT][BOARD_WIDTH];
        for (int i = 0; i < BOARD_HEIGHT; i++) {
            for (int j = 0; j < BOARD_WIDTH; j++) {
                this.board[i][j] = new Tile(j, i);
            }
        }

        Random random = new Random();
        int displacedMines = 0;
        while (displacedMines < numberMines) {
            int row = random.nextInt(BOARD_HEIGHT);
            int col = random.nextInt(BOARD_WIDTH);
            if (!board[row][col].hasMine()) {
                board[row][col].setMine(true);
                displacedMines++;
            }
        }

        for (int i = 0; i < BOARD_HEIGHT; i++) {
            for (int j = 0; j < BOARD_WIDTH; j++) {
                board[i][j].countAdjacentMines(this);
            }
        }
    }

    @Override
    public void draw() {
        background(200, 200, 200);

        if (!gameOver && !gameWon) {
            passedTime = frameCount / FPS;
        }
        textSize(20);
        fill(0);
        text("Time: " + passedTime + "s", WIDTH - 120, 40);

        int nonRevealedNonMines = 0;
        for (int i = 0; i < BOARD_HEIGHT; i++) {
            for (int j = 0; j < BOARD_WIDTH; j++) {
                this.board[i][j].draw(this);
                if (!this.board[i][j].isRevealed() && !this.board[i][j].hasMine()) {
                    nonRevealedNonMines++;
                }
            }
        }

        if (nonRevealedNonMines == 0 && !gameOver) {
            gameWon = true;
            textSize(30);
            fill(0, 255, 0);
            text("You win!", WIDTH / 2 - 60, TOPBAR - 10);
        }

        if (gameOver) {
            if (explosionStartFrame == -1) {
                explosionStartFrame = frameCount;
                for (int i = 0; i < BOARD_HEIGHT; i++) {
                    for (int j = 0; j < BOARD_WIDTH; j++) {
                        if (board[i][j].hasMine()) {
                            explodingMines.add(board[i][j]);
                        }
                    }
                }
            }
            triggerMineExplosions();
            textSize(30);
            fill(255, 0, 0);
            text("You Lost!", WIDTH / 2 - 60, TOPBAR - 10);
        }
    }

    private void triggerMineExplosions() {
        int currentFrame = frameCount;
        int explosionIndex = (currentFrame - explosionStartFrame) / 3;

        for (int i = 0; i < explodingMines.size(); i++) {
            if (i <= explosionIndex && i < explodingMines.size()) {
                explodingMines.get(i).setExploding(true);
            }
        }
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        int mouseX = e.getX();
        int mouseY = e.getY() - TOPBAR;

        if (mouseX >= 0 && mouseX < WIDTH && mouseY >= 0 && mouseY < HEIGHT - TOPBAR) {
            Tile t = board[mouseY / CELLSIZE][mouseX / CELLSIZE];
            if (mouseButton == LEFT && !gameOver && !gameWon && !t.isFlagged()) {
                t.reveal(this);
                if (t.hasMine()) {
                    gameOver = true;
                }
            } else if (mouseButton == RIGHT && !gameOver && !gameWon) {
                t.switchFlag();
            }
        }
    }

    @Override
    public void keyPressed() {
        if (key == 'r' || key == 'R') {
            resetGame();
        }
    }

    public static void main(String[] args) {
        PApplet.main("minesweeper.App", args);
    }
}
