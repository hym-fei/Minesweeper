package minesweeper;

import processing.core.PImage;
import java.util.ArrayList;
import java.util.List;

public class Tile {

    private boolean revealed;
    private boolean flagged;
    private boolean mine;
    private boolean exploding;
    private int adjacentMines;
    private int x, y;
    private int explosionFrame = 0;
    private boolean explosionComplete = false;

    public Tile(int x, int y) {
        this.x = x;
        this.y = y;
        this.revealed = false;
        this.flagged = false;
        this.mine = false;
        this.exploding = false;
        this.adjacentMines = 0;
    }

    public void countAdjacentMines(App app) {
        adjacentMines = 0;
        for (Tile neighbor : getAdjacentTiles(app)) {
            if (neighbor.hasMine()) {
                adjacentMines++;
            }
        }
    }

    public void draw(App app) {
        PImage tile = app.getS1("tile1");

        if (flagged) {

            tile = app.getS1("tile1");
            app.image(tile, x * App.CELLSIZE, y * App.CELLSIZE + App.TOPBAR);
            PImage flagImage = app.getS1("flag");
            app.image(flagImage, x * App.CELLSIZE, y * App.CELLSIZE + App.TOPBAR);

            return;
        }

        if (revealed) {
            if (mine) {
                tile = app.getS1("tile");
            } else {
                tile = app.getS1("tile");
            }
        } else if (app.mouseX >= x * App.CELLSIZE && app.mouseX < (x + 1) * App.CELLSIZE &&
                app.mouseY >= y * App.CELLSIZE + App.TOPBAR && app.mouseY < (y + 1) * App.CELLSIZE + App.TOPBAR) {
            tile = app.getS1("tile2");
        }

        app.image(tile, x * App.CELLSIZE, y * App.CELLSIZE + App.TOPBAR);

        if (revealed && !mine && adjacentMines > 0) {
            app.fill(0);
            app.textSize(20);
            app.text(adjacentMines, x * App.CELLSIZE + 12, y * App.CELLSIZE + App.TOPBAR + 20);
        }

        if (exploding && mine) {

            if (!explosionComplete) {
                int index = explosionFrame / 3;
                if (index < 10) {
                    PImage explosionImg = app.getS1("mine" + index);
                    app.image(explosionImg, x * App.CELLSIZE, y * App.CELLSIZE + App.TOPBAR);
                }

                explosionFrame++;
                if (explosionFrame >= 30) {
                    explosionComplete = true;
                }
            } else {
                PImage lastExplosionImg = app.getS1("mine9");
                app.image(lastExplosionImg, x * App.CELLSIZE, y * App.CELLSIZE + App.TOPBAR);
            }
        }
    }

    public void reveal(App app) {
        if (!flagged && !revealed) {
            revealed = true;

            if (mine) {
                app.gameOver = true;
            } else {
                if (adjacentMines == 0) {
                    for (Tile neighbor : getAdjacentTiles(app)) {
                        if (!neighbor.isRevealed()) {
                            neighbor.reveal(app);
                        }
                    }
                }
            }
        }
    }

    public boolean isRevealed() {
        return revealed;
    }

    public boolean hasMine() {
        return mine;
    }

    public void setMine(boolean mine) {
        this.mine = mine;
    }

    public void setExploding(boolean exploding) {
        this.exploding = exploding;
    }

    public void switchFlag() {
        if (!revealed) {
            flagged = !flagged;
        }
    }

    public boolean isFlagged() {
        return flagged;
    }

    public List<Tile> getAdjacentTiles(App app) {
        List<Tile> adjacentTiles = new ArrayList<>();
        int[][] directions = {{-1, -1}, {-1, 0}, {-1, 1}, {0, -1}, {0, 1}, {1, -1}, {1, 0}, {1, 1}};

        for (int[] direction : directions) {
            int newX = x + direction[0];
            int newY = y + direction[1];
            if (newX >= 0 && newX < App.BOARD_WIDTH && newY >= 0 && newY < App.BOARD_HEIGHT) {
                adjacentTiles.add(app.getBoard()[newY][newX]);
            }
        }

        return adjacentTiles;
    }
}
